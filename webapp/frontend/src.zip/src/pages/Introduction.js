import { Link, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";

export default function Introduction() {
  return (
    <div>Introduction1</div>
  );
}