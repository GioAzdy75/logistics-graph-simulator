import { Link, useNavigate } from "react-router-dom";

export default function Clientes() {
    
  return (
    <div>
      <>Seccion Clientes</>
    </div>
  );
}