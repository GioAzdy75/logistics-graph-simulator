import { Link, useNavigate } from "react-router-dom";

export default function Sidebar() {
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };
  return (
    <aside className="w-64 bg-gray-900 text-white h-screen fixed top-0 left-0 z-20 flex flex-col">
      <div className="p-4 border-b border-gray-700">
        <h1 className="text-lg font-semibold">Optimización de Rutas</h1>
      </div>
      <nav className="flex-1 p-4 space-y-4 text-sm">
        <ul className="space-y-2">
          <li><Link to="/" className="text-blue-400 hover:underline">Introducción</Link></li>
          <li><Link to="/clientes" className="text-blue-400 hover:underline">Clientes</Link></li>
          <li><Link to="/locales" className="text-blue-400 hover:underline">Locales y Distribución</Link></li>
        </ul>
      </nav>
      <button
        onClick={handleLogout}
        className="m-4 mt-auto bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded"
      >
        Cerrar sesión
      </button>
    </aside>
  );
}
